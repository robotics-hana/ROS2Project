// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AR_INTERFACE__MSG__CUBIC_TRAJ_COEFFS_HPP_
#define AR_INTERFACE__MSG__CUBIC_TRAJ_COEFFS_HPP_

#include "ar_interface/msg/detail/cubic_traj_coeffs__struct.hpp"
#include "ar_interface/msg/detail/cubic_traj_coeffs__builder.hpp"
#include "ar_interface/msg/detail/cubic_traj_coeffs__traits.hpp"
#include "ar_interface/msg/detail/cubic_traj_coeffs__type_support.hpp"

#endif  // AR_INTERFACE__MSG__CUBIC_TRAJ_COEFFS_HPP_
