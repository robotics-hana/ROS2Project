// generated from rosidl_generator_c/resource/idl.h.em
// with input from ar_interface:srv/ComputeCubicTraj.idl
// generated code does not contain a copyright notice

#ifndef AR_INTERFACE__SRV__COMPUTE_CUBIC_TRAJ_H_
#define AR_INTERFACE__SRV__COMPUTE_CUBIC_TRAJ_H_

#include "ar_interface/srv/detail/compute_cubic_traj__struct.h"
#include "ar_interface/srv/detail/compute_cubic_traj__functions.h"
#include "ar_interface/srv/detail/compute_cubic_traj__type_support.h"

#endif  // AR_INTERFACE__SRV__COMPUTE_CUBIC_TRAJ_H_
