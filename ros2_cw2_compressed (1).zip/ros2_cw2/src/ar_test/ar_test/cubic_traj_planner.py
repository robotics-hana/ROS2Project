import rclpy
from rclpy.node import Node
from ar_interface.msg import CubicTrajParams, CubicTrajCoeffs
from ar_interface.srv import ComputeCubicTraj

class CubicTrajPlanner(Node):
    def __init__(self):
        super().__init__('cubic_traj_planner')
        self.subscription = self.create_subscription(CubicTrajParams, 'cubic_traj_params', self.process_trajectory, 10)
        self.publisher = self.create_publisher(CubicTrajCoeffs, 'cubic_traj_coeffs', 10)
        self.client = self.create_client(ComputeCubicTraj, 'compute_cubic_traj')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for compute_cubic_traj service...')

    def process_trajectory(self, msg):
        request = ComputeCubicTraj.Request()
        request.p0, request.pf, request.v0, request.vf, request.t0, request.tf = msg.p0, msg.pf, msg.v0, msg.vf, msg.t0, msg.tf
        future = self.client.call_async(request)
        future.add_done_callback(lambda f: self.publish_coeffs(f.result(), msg.t0, msg.tf))

    def publish_coeffs(self, response, t0, tf):
        msg = CubicTrajCoeffs()
        msg.a0, msg.a1, msg.a2, msg.a3, msg.t0, msg.tf = response.a0, response.a1, response.a2, response.a3, t0, tf
        self.publisher.publish(msg)
        self.get_logger().info(f'Published trajectory coefficients: {msg}')


def main(args=None):
    rclpy.init()
    node = CubicTrajPlanner()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()



