import rclpy

from rclpy.node import Node

from ar_interface.msg import CubicTrajCoeffs

from std_msgs.msg import Float64

import numpy as np

 

class PlotCubicTraj(Node):

    def __init__(self):

        super().__init__('plot_cubic_traj')

        self.subscription = self.create_subscription(

            CubicTrajCoeffs,

            'cubic_traj_coeffs',

            self.listener_callback,

            10)

       

        # Publishers for position, velocity, and acceleration trajectories

        self.pos_pub = self.create_publisher(Float64, 'position_traj', 10)

        self.vel_pub = self.create_publisher(Float64, 'velocity_traj', 10)

        self.acc_pub = self.create_publisher(Float64, 'acceleration_traj', 10)

       

        # Variables to store the entire trajectory history

        self.time_history = []

        self.position_history = []

        self.velocity_history = []

        self.acceleration_history = []

 

    def listener_callback(self, msg):

        t0 = msg.t0

        tf = msg.tf

        time = np.linspace(t0, tf, 100)  # Generate 100 time points between t0 and tf

 

        # Compute position, velocity, and acceleration for the current trajectory

        position = msg.a0 + msg.a1 * time + msg.a2 * time**2 + msg.a3 * time**3

        velocity = msg.a1 + 2 * msg.a2 * time + 3 * msg.a3 * time**2

        acceleration = 2 * msg.a2 + 6 * msg.a3 * time

 

        # Append the current trajectory to the history

        self.time_history.extend(time)

        self.position_history.extend(position)

        self.velocity_history.extend(velocity)

        self.acceleration_history.extend(acceleration)

 

        # Publish the entire trajectory history

        for t, pos, vel, acc in zip(self.time_history, self.position_history, self.velocity_history, self.acceleration_history):

            self.pos_pub.publish(Float64(data=pos))

            self.vel_pub.publish(Float64(data=vel))

            self.acc_pub.publish(Float64(data=acc))

            self.get_logger().info(f'Publishing trajectories at t={t}')

 

def main(args=None):

    rclpy.init(args=args)

    plot_cubic_traj = PlotCubicTraj()

    rclpy.spin(plot_cubic_traj)

    plot_cubic_traj.destroy_node()

    rclpy.shutdown()

 

if __name__ == '__main__':

    main()

