// generated from rosidl_generator_c/resource/idl.h.em
// with input from ar_interface:msg/CubicTrajParams.idl
// generated code does not contain a copyright notice

#ifndef AR_INTERFACE__MSG__CUBIC_TRAJ_PARAMS_H_
#define AR_INTERFACE__MSG__CUBIC_TRAJ_PARAMS_H_

#include "ar_interface/msg/detail/cubic_traj_params__struct.h"
#include "ar_interface/msg/detail/cubic_traj_params__functions.h"
#include "ar_interface/msg/detail/cubic_traj_params__type_support.h"

#endif  // AR_INTERFACE__MSG__CUBIC_TRAJ_PARAMS_H_
