// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AR_INTERFACE__MSG__CUBIC_TRAJ_PARAMS_HPP_
#define AR_INTERFACE__MSG__CUBIC_TRAJ_PARAMS_HPP_

#include "ar_interface/msg/detail/cubic_traj_params__struct.hpp"
#include "ar_interface/msg/detail/cubic_traj_params__builder.hpp"
#include "ar_interface/msg/detail/cubic_traj_params__traits.hpp"
#include "ar_interface/msg/detail/cubic_traj_params__type_support.hpp"

#endif  // AR_INTERFACE__MSG__CUBIC_TRAJ_PARAMS_HPP_
